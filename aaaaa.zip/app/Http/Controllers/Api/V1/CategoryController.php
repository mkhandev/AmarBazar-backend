<?php
namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::with('children')->get();
        return response()->json($categories);
    }

    public function show($id)
    {}

    public function store(Request $request)
    {}

    public function update(Request $request, $id)
    {

    }

    public function destroy($id)
    {}
}
